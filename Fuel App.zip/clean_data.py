# -*- coding: utf-8 -*-
"""
DSP Scheduling - Talend Production Engine
Purpose: Clean, merge, and generate synthetic features for EV Revenue Data.
"""

import os
import sys
import pandas as pd
import numpy as np

def main():
    # -------------------------------------------------------------
    # 1. READ INPUT FILES
    # In production, ensure these files exist in the working directory
    # -------------------------------------------------------------
    try:
        data = pd.read_csv('kuantan_ev_revenue.csv')
        population = pd.read_csv('population_dun.csv')
    except FileNotFoundError as e:
        print(f"Error: Missing input file -> {e}")
        sys.exit(1)

    # -------------------------------------------------------------
    # 2. DATA PRE-PROCESSING & FILTERING
    # -------------------------------------------------------------
    # Filter for 2022 Pahang overall population data
    kuantan_pop = population[population['state'].str.contains('Pahang', case=False, na=False)]
    kuantan_pop_2022 = kuantan_pop[kuantan_pop['date'].str.contains('2022', na=False)]
    kuantan_pop_2022 = kuantan_pop_2022[(kuantan_pop_2022['sex'] == 'both') & (kuantan_pop_2022['ethnicity'] == 'overall')]

    # -------------------------------------------------------------
    # 3. POSTCODE TO DUN MAPPING
    # -------------------------------------------------------------
    postcode_dun_mapping_dict = {
        26300: 'N.18 Lepar',
        25300: 'N.19 Panching',
        25150: 'N.14 Teruntum',
        25000: 'N.14 Teruntum',
        25100: 'N.14 Teruntum',
        25050: 'N.14 Teruntum',
        25250: 'N.15 Tanjung Lumpur',
        25200: 'N.13 Semambu',
        26080: 'N.17 Sungai Lembing',
        25350: 'N.13 Semambu',
        26060: 'N.18 Lepar',
        26100: 'N.17 Sungai Lembing',
        25990: 'N.16 Inderapura'
    }
    
    postcode_dun_df = pd.DataFrame(list(postcode_dun_mapping_dict.items()), columns=['Postcode', 'dun'])

    # -------------------------------------------------------------
    # 4. DATA MERGING & CLEANING
    # -------------------------------------------------------------
    merged_data = pd.merge(data, postcode_dun_df, on='Postcode', how='left')
    final_merged_df = pd.merge(merged_data, kuantan_pop_2022, on='dun', how='left')
    
    # Drop unneeded administrative columns to keep data lightweight
    columns_to_drop = ['dun', 'date', 'state', 'parlimen', 'sex', 'age', 'ethnicity']
    final_merged_df = final_merged_df.drop(columns=[col for col in columns_to_drop if col in final_merged_df.columns])

    # -------------------------------------------------------------
    # 5. SYNTHETIC FEATURE GENERATION (ADT & PEAK HOUR FLAGS)
    # -------------------------------------------------------------
    np.random.seed(2111)

    def generate_adt(pop):
        if pop < 25:
            return np.random.randint(8000, 15001)
        elif 25 <= pop < 60:
            return np.random.randint(15000, 30001)
        elif 60 <= pop < 120:
            return np.random.randint(30000, 50001)
        else:
            return np.random.randint(50000, 80001)

    final_merged_df["ADT"] = final_merged_df["population"].apply(generate_adt)

    # Clean up redundant column variations if present
    if 'ADT_synthetic' in final_merged_df.columns:
        final_merged_df = final_merged_df.drop(columns=['ADT_synthetic'])

    # Peak hour logic calculation
    URBAN_KEYWORDS = ["city", "mall", "bandar", "pusat", "square", "komersial", "commercial", "downtown", "indera mahkota", "kuantan city"]
    
    def is_urban(address):
        if pd.isna(address):
            return False
        return any(keyword in str(address).lower() for keyword in URBAN_KEYWORDS)

    def peak_hour(row):
        urban = is_urban(row["Station Address"])
        pop = row["population"]
        adt = row["ADT"]
        if urban and (pop >= 60 or adt >= 30000):
            return "Yes"
        return "No"

    final_merged_df["Peak_Hour"] = final_merged_df.apply(peak_hour, axis=1)

    # Calculate utilization proxy target for next stages
    final_merged_df["utilization_score"] = final_merged_df["Total_revenue (RM)"] / final_merged_df["Total Station Capacity (KW)"]

    # -------------------------------------------------------------
    # 6. OUTPUT EXPORT FOR TALEND DOWNLOAD
    # -------------------------------------------------------------
    final_merged_df.to_csv('final_clean_data.csv', index=False)
    print("SUCCESS: Data successfully cleaned, merged, and saved to final_clean_data.csv")

if __name__ == "__main__":
    main()